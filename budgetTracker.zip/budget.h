#ifndef BUDGET_H
#define BUDGET_H

#include "data.h"

// Core Menu Features
void displayMenu();
void displayEntries(Entry *entries, int size);
void expenseDistribution(Entry *entries, int size);
void addEntry(Entry **entries, int *size);
void modifyEntry(Entry *entries, int size);
void filterByMonth(Entry *entries, int size);

// Extra Credit Features
void visualExpenseBreakdown(Entry *entries, int size);
void searchByAmountRange(Entry *entries, int size);
void undoLastAction(Entry **entries, int *size);

#endif
