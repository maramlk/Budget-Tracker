#include <stdio.h>
#include <stdlib.h>
#include "data.h"
#include "budget.h"
#include "ordering.h"

// Clears leftover input after scanf
void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <inputfile>\n", argv[0]);
        return 1;
    }

    Entry *entries = NULL;
    int size = 0;

    if (loadEntries(argv[1], &entries, &size) != 0) {
        return 1;
    }

    int choice;
    do {
        displayMenu();
        scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                displayEntries(entries, size);
                break;
            case 2:
                expenseDistribution(entries, size);
                break;
            case 3:
                sortMenu(entries, size);
                displayEntries(entries, size);
                break;
            case 4:
                addEntry(&entries, &size);
                break;
            case 5:
                modifyEntry(entries, size);
                break;
            case 6:
                filterByMonth(entries, size);
                break;
            case 7:
                printf("Goodbye and thanks for using our budget tracker app.\n");
                break;
            case 8:
                visualExpenseBreakdown(entries, size);
                break;
            case 9:
                searchByAmountRange(entries, size);
                break;
            case 10:
                undoLastAction(&entries, &size);
                break;
            default:
                printf("Feature not implemented yet.\n");
        }

    } while (choice != 7);

    freeEntries(entries);
    return 0;
}
