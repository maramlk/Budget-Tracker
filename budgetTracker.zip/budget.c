#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "budget.h"

// Undo state tracking
static Entry lastRemoved;
static int lastRemovedValid = 0;

// Existing Menu and Entry Management Functions Here...

void displayMenu() {
    printf("\nBudget Tracking System\n");
    printf("=====================\n");
    printf("1. Display all entries\n");
    printf("2. Expense Distribution\n");
    printf("3. Sort Entries\n");
    printf("4. Add Income/Expense Entry\n");
    printf("5. Modify Entry\n");
    printf("6. Filter by Month\n");
    printf("7. Exit\n");
    printf("8. Visual Expense Breakdown\n");
    printf("9. Search Transactions by Amount Range\n");
    printf("10. Undo Last Action\n");
    printf("Choice: ");
}

void displayEntries(Entry *entries, int size) {
    printf("\nFinances Summary\n");
    printf("=================\n");
    printf("\nID    Date       Type       Category        Description     Amount\n");
    printf("---------------------------------------------------------------\n");
    for (int i = 0; i < size; i++) {
        printf("%-5d %-10s %-10s %-15s %-15s $%.2f\n",
               entries[i].id, entries[i].date, entries[i].type,
               entries[i].category, entries[i].description, entries[i].amount);
    }
}

void expenseDistribution(Entry *entries, int size) {
    double totalIncome = 0.0, totalExpenses = 0.0, needs = 0.0, wants = 0.0;

    for (int i = 0; i < size; i++) {
        if (strcmp(entries[i].type, "income") == 0) {
            totalIncome += entries[i].amount;
        } else if (strcmp(entries[i].type, "expense") == 0) {
            totalExpenses += entries[i].amount;
            if (strcmp(entries[i].category, "Needs") == 0) needs += entries[i].amount;
            else if (strcmp(entries[i].category, "Wants") == 0) wants += entries[i].amount;
        }
    }

    printf("\n===== Expense Distribution Report =====\n");
    printf("Total Income: $%.2f\n", totalIncome);
    printf("Total Expenses: $%.2f\n", totalExpenses);
    printf("Needs: $%.2f\n", needs);
    printf("Wants: $%.2f\n", wants);
    printf("Net Balance: $%.2f\n", totalIncome - totalExpenses);
    printf("======================================\n");
}

void getCurrentDate(char *buffer, int bufferSize) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    strftime(buffer, bufferSize, "%Y-%m-%d", t);
}

void addEntry(Entry **entries, int *size) {
    *entries = realloc(*entries, (*size + 1) * sizeof(Entry));
    Entry *newEntry = &((*entries)[*size]);

    int maxId = 0;
    for (int i = 0; i < *size; i++) {
        if ((*entries)[i].id > maxId) maxId = (*entries)[i].id;
    }
    newEntry->id = maxId + 1;

    char choice;
    printf("\nUse today's date? (y/n): ");
    scanf(" %c", &choice);

    if (choice == 'y' || choice == 'Y') {
        getCurrentDate(newEntry->date, sizeof(newEntry->date));
    } else {
        printf("Enter date (YYYY-MM-DD): ");
        scanf("%10s", newEntry->date);
    }

    printf("Type (income/expense): ");
    scanf("%9s", newEntry->type);
    printf("Category: ");
    scanf("%19s", newEntry->category);
    printf("Description: ");
    scanf("%100s", newEntry->description);
    printf("Amount: ");
    scanf("%lf", &newEntry->amount);

    printf("Entry added successfully with ID: %d\n", newEntry->id);
    (*size)++;

    lastRemoved = *newEntry;
    lastRemovedValid = 1;
}

void modifyEntry(Entry *entries, int size) {
    displayEntries(entries, size);

    int targetId;
    printf("\nEnter ID of entry to modify: ");
    scanf("%d", &targetId);

    int found = -1;
    for (int i = 0; i < size; i++) {
        if (entries[i].id == targetId) {
            found = i;
            break;
        }
    }

    if (found == -1) {
        printf("Entry with ID %d not found.\n", targetId);
        return;
    }

    Entry *e = &entries[found];
    printf("\nCurrent Details:\nID: %d\nDate: %s\nType: %s\nCategory: %s\nDescription: %s\nAmount: $%.2f\n",
           e->id, e->date, e->type, e->category, e->description, e->amount);

    int choice;
    printf("\nWhat would you like to modify?\n1. Date\n2. Amount\nChoice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("Enter new date (YYYY-MM-DD): ");
        scanf("%10s", e->date);
    } else if (choice == 2) {
        printf("Enter new amount: ");
        scanf("%lf", &e->amount);
    } else {
        printf("Invalid choice.\n");
        return;
    }

    printf("Entry updated successfully.\n");

    lastRemoved = *e;
    lastRemovedValid = 1;
}

void filterByMonth(Entry *entries, int size) {
    int year, month;
    printf("\nEnter year (YYYY): ");
    scanf("%d", &year);
    printf("Enter month (1-12): ");
    scanf("%d", &month);

    char target[8];
    snprintf(target, sizeof(target), "%04d-%02d", year, month);

    printf("\nEntries for %s:\n", target);
    printf("ID    Date       Type       Category        Description     Amount\n");
    printf("---------------------------------------------------------------\n");

    int found = 0;
    for (int i = 0; i < size; i++) {
        if (strncmp(entries[i].date, target, 7) == 0) {
            printf("%-5d %-10s %-10s %-15s %-15s $%.2f\n",
                   entries[i].id, entries[i].date, entries[i].type,
                   entries[i].category, entries[i].description, entries[i].amount);
            found = 1;
        }
    }

    if (!found) {
        printf("No entries found for this month.\n");
    }
}

// Visual Breakdown
void visualExpenseBreakdown(Entry *entries, int size) {
    double needs = 0.0, wants = 0.0, other = 0.0;
    for (int i = 0; i < size; i++) {
        if (strcmp(entries[i].type, "expense") == 0) {
            if (strcmp(entries[i].category, "Needs") == 0) needs += entries[i].amount;
            else if (strcmp(entries[i].category, "Wants") == 0) wants += entries[i].amount;
            else other += entries[i].amount;
        }
    }
    printf("\nExpense Breakdown:\n");
    printf("Needs: $%.2f | ", needs); for (int i = 0; i < (int)(needs / 10); i++) printf("*"); printf("\n");
    printf("Wants: $%.2f | ", wants); for (int i = 0; i < (int)(wants / 10); i++) printf("*"); printf("\n");
    printf("Other: $%.2f | ", other); for (int i = 0; i < (int)(other / 10); i++) printf("*"); printf("\n");
}

// Search by Amount Range
void searchByAmountRange(Entry *entries, int size) {
    double minAmount, maxAmount;
    printf("\nEnter minimum amount: ");
    scanf("%lf", &minAmount);
    printf("Enter maximum amount: ");
    scanf("%lf", &maxAmount);

    printf("\nTransactions between $%.2f and $%.2f:\n", minAmount, maxAmount);
    printf("ID    Date       Type       Category        Description     Amount\n");
    printf("---------------------------------------------------------------\n");

    int found = 0;
    for (int i = 0; i < size; i++) {
        if (entries[i].amount >= minAmount && entries[i].amount <= maxAmount) {
            printf("%-5d %-10s %-10s %-15s %-15s $%.2f\n",
                   entries[i].id, entries[i].date, entries[i].type,
                   entries[i].category, entries[i].description, entries[i].amount);
            found = 1;
        }
    }

    if (!found) {
        printf("No transactions found in this range.\n");
    }
}

// Undo Last Action
void undoLastAction(Entry **entries, int *size) {
    if (lastRemovedValid) {
        *entries = realloc(*entries, (*size + 1) * sizeof(Entry));
        (*entries)[*size] = lastRemoved;
        (*size)++;
        printf("\nUndo successful. Restored last removed entry with ID: %d\n", lastRemoved.id);
        lastRemovedValid = 0;
    } else {
        printf("\nNo action to undo.\n");
    }
}
