#ifndef ORDERING_H
#define ORDERING_H
#include "data.h"

void sortMenu(Entry *entries, int size);

#endif
