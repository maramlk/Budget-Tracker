#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
#include "ordering.h"

int compareById(const void *a, const void *b) {
    return ((Entry *)a)->id - ((Entry *)b)->id;
}

int compareByAmount(const void *a, const void *b) {
    double diff = ((Entry *)a)->amount - ((Entry *)b)->amount;
    return (diff > 0) - (diff < 0);
}

int compareByDate(const void *a, const void *b) {
    return strcmp(((Entry *)a)->date, ((Entry *)b)->date);
}

int compareByDescription(const void *a, const void *b) {
    return strcmp(((Entry *)a)->description, ((Entry *)b)->description);
}

void sortMenu(Entry *entries, int size) {
    int option;
    printf("\nSort Menu\n");
    printf("1. Sort by ID\n2. Sort by Date\n3. Sort by Amount\n4. Sort by Description\nChoice: ");
    scanf("%d", &option);

    switch (option) {
        case 1: qsort(entries, size, sizeof(Entry), compareById); break;
        case 2: qsort(entries, size, sizeof(Entry), compareByDate); break;
        case 3: qsort(entries, size, sizeof(Entry), compareByAmount); break;
        case 4: qsort(entries, size, sizeof(Entry), compareByDescription); break;
        default: printf("Invalid option.\n"); return;
    }

    printf("Entries sorted by amount.\n");
}
