#ifndef DATA_H
#define DATA_H

typedef struct {
    int id;
    char date[11];        // YYYY-MM-DD
    char type[10];        // income/expense
    char category[20];    // Needs/Wants/Passive/Active
    char description[101];
    double amount;
} Entry;

int loadEntries(const char *filename, Entry **entries, int *size);
void freeEntries(Entry *entries);

#endif
