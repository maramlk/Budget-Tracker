#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"

int loadEntries(const char *filename, Entry **entries, int *size) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Error opening file.\n");
        return -1;
    }

    *size = 0;
    *entries = NULL;
    char buffer[512];

    while (fgets(buffer, sizeof(buffer), file)) {
        *entries = realloc(*entries, (*size + 1) * sizeof(Entry));
        Entry *e = &((*entries)[*size]);
        sscanf(buffer, "%d|%10[^|]|%9[^|]|%19[^|]|%100[^|]|%lf",
               &e->id, e->date, e->type, e->category, e->description, &e->amount);
        (*size)++;
    }

    fclose(file);
    return 0;
}

void freeEntries(Entry *entries) {
    free(entries);
}
